# SOLO SYSTEM — Android foundation

A native Kotlin + Jetpack Compose offline starter for the OPPO Android target.

## Current foundation
- Solo Leveling-inspired dark holographic dashboard
- Player level and XP progress
- Daily quest accept/complete flow
- XP/level progression
- Local persistence with SharedPreferences

## Build
1. Open this folder in Android Studio (recent version with Android SDK 35 support).
2. Let Gradle sync.
3. Build > Build APK(s), or run `./gradlew assembleDebug` from a machine with Android SDK installed.
4. Install the debug APK on the OPPO phone and allow installation from that source when Android asks.

APK output after a successful build: `app/build/outputs/apk/debug/app-debug.apk`.

## Important
This starter is not yet the full requested system popup/lock-screen implementation. Android restricts background launches and overlay behavior; that stage should add user-enabled overlay access, notification channels, scheduled reminders, and appropriate Android version handling. The project cannot be built in this chat runtime because Android SDK/Gradle are not installed, and I cannot remotely install an APK onto your phone.

## Build using only an Android phone (GitHub Actions)
1. Create a GitHub account or sign in in your phone browser.
2. Create a new repository and upload the contents of this project (including `.github/workflows/android-apk.yml`).
3. Open the repository's **Actions** tab.
4. Select **Build SOLO SYSTEM APK** > **Run workflow**.
5. When the run finishes, open it and download the `solo-system-debug-apk` artifact.
6. Extract the ZIP and tap `app-debug.apk` to install. Android may ask you to allow installs from your browser/files app.

This workflow builds the APK on GitHub's runner; it does not require a PC. The app is a starter foundation, not yet the complete popup/lock-screen System.
