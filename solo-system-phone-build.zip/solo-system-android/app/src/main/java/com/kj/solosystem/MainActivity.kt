package com.kj.solosystem

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Context

private val Night = Color(0xFF050B16)
private val Panel = Color(0xFF0B1A2C)
private val Cyan = Color(0xFF55D7FF)
private val Muted = Color(0xFF9DBBD0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SoloSystemApp(this) }
    }
}

@Composable
private fun SoloSystemApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("solo_system", Context.MODE_PRIVATE) }
    var xp by remember { mutableIntStateOf(prefs.getInt("xp", 0)) }
    var level by remember { mutableIntStateOf(prefs.getInt("level", 1)) }
    var done by remember { mutableStateOf(prefs.getBoolean("daily_done", false)) }
    var accepted by remember { mutableStateOf(prefs.getBoolean("daily_accepted", false)) }
    val nextLevel = 100 + (level - 1) * 25
    val progress = (xp.toFloat() / nextLevel).coerceIn(0f, 1f)

    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Cyan,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Night).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("SOLO SYSTEM", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("PLAYER: KJ  •  SYSTEM ONLINE", color = Muted, fontSize = 12.sp, letterSpacing = 1.5.sp)

            PanelCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("PLAYER STATUS", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("LEVEL $level", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                        Text("E-RANK HUNTER", color = Muted, fontSize = 13.sp)
                    }
                    Text("✦", color = Cyan, fontSize = 54.sp)
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("XP", color = Muted); Text("$xp / $nextLevel", color = Cyan, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Cyan, trackColor = Color(0xFF1B344A))
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Stat("STR", "10"); Stat("AGI", "10"); Stat("VIT", "10"); Stat("INT", "10"); Stat("SEN", "10")
                }
            }

            PanelCard {
                Text("DAILY QUEST", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(8.dp))
                Text("THE PLAYER'S ROUTINE", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Complete a small real-world task to earn XP. Your progress is saved locally on this device.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Text("• 10-minute movement session\n• Drink a glass of water\n• Tidy one small area", lineHeight = 23.sp)
                Spacer(Modifier.height(12.dp))
                if (done) {
                    Text("QUEST COMPLETE  •  +25 XP", color = Cyan, fontWeight = FontWeight.Bold)
                } else if (!accepted) {
                    Button(onClick = { accepted = true; prefs.edit().putBoolean("daily_accepted", true).apply() }, modifier = Modifier.fillMaxWidth()) { Text("ACCEPT QUEST") }
                } else {
                    Button(onClick = {
                        done = true
                        accepted = false
                        xp += 25
                        while (xp >= (100 + (level - 1) * 25)) {
                            xp -= (100 + (level - 1) * 25)
                            level += 1
                        }
                        prefs.edit().putInt("xp", xp).putInt("level", level).putBoolean("daily_done", true).putBoolean("daily_accepted", false).apply()
                    }, modifier = Modifier.fillMaxWidth()) { Text("COMPLETE QUEST  •  +25 XP") }
                }
            }

            PanelCard {
                Text("SYSTEM NOTICE", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(6.dp))
                Text("This is the first offline foundation. Popup-over-other-apps, scheduled reminders, and rank unlocks are planned for the next build stage and require Android permissions/settings.", color = Muted, fontSize = 13.sp)
            }
            Text("OFFLINE MODE  •  LOCAL SAVE", color = Muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp))
            .border(1.dp, Color(0xFF24506B), RoundedCornerShape(14.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp), content = content
    )
}
